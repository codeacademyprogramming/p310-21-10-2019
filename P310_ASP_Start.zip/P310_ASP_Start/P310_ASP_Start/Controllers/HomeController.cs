﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P310_ASP_Start.DAL;
using P310_ASP_Start.Models;
using P310_ASP_Start.ViewModels;

namespace P310_ASP_Start.Controllers
{
    public class HomeController : Controller
    {
        private readonly EliteContext _context;

        public HomeController(EliteContext context)
        {
            _context = context;
        }

        public ViewResult Index()
        {
            HomeIndexVM homeIndexVM = new HomeIndexVM()
            {
                Sliders = _context.Sliders,
                NewArrivals = _context.NewArrivals,
                NewProducts = _context.Products.Where(p => p.IsNew).ToList(),
                Categories = _context.Categories
            };
            return View(homeIndexVM);
        }

        public ViewResult About()
        {
            return View();
        }
    }
}