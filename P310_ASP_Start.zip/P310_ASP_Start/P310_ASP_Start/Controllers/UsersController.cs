﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P310_ASP_Start.Controllers
{
    public class UsersController
    {
        public string GetAll()
        {
            return "Ruslan, Ibo, Perviz";
        }
    }
}
