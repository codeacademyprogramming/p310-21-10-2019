function User(name_surname,email,password,confirm_password){

    this.name_surname = name_surname;
    this.email = email;
    this.password = password;
    this.confirm_password = confirm_password;
}